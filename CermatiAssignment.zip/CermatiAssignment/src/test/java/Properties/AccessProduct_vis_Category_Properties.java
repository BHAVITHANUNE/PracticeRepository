package Properties;

import org.openqa.selenium.By;

public class AccessProduct_vis_Category_Properties {

	public static final By homePgae = By.xpath("//*[text()='eBay Home']");

	public static final By ShopCategory = By.xpath("//*[text()=' Shop by category']");

	public static final By CellPhonesAccessories = By.xpath("//*[text()='Cell phones & accessories']");

	public static final By CellPhonesCategoryPage = By.xpath("(//*[text()='Shop by Category'])[1]");

	public static final By CellPhonesSmartPhones = By.xpath("(//*[text()='Cell Phones & Smartphones'])[1]");

	public static final By Filters = By.xpath("//*[text()='All Filters']");

	public static final By Condition = By.xpath("(//*[text()='Condition'])[2]");

	public static final By Price = By.xpath("(//*[text()='Price'])[2]");

	public static final By ItemLocation = By.xpath("//*[text()='Item Location']");

	public static By Itemlocation (String Location) {
		return By.xpath("//*[@value='"+Location+"']");
	}

	public static By Condition(String Condition) {
		return By.xpath("(//*[text()='"+Condition+"'])[2]");
	}

	/*public static By (String ) {
		return By.xpath("");
	}*/

	/*public static By (String ) {
		return By.xpath("");
	}*/

	/*public static By (String ) {
		return By.xpath("");
	}*/

	public static final By  MinPrice= By.xpath("//*[@aria-label='Minimum Value, US Dollar']");

	public static final By MaxPrice = By.xpath("//*[@aria-label='Maximum Value, US Dollar']");
	
	public static final By ApplyButton = By.xpath("//*[button='Apply']");
	
	public static final By FilterAppled = By.xpath("//h1//*[contains(text(),'Cell Phones & Smartphones between')]");
	
	public static final By itemsFound = By.xpath("//*[contains(text(),' items found from eBay')]");
	
//	public static final By MaxPrice = By.xpath("");

//	public static final By MaxPrice = By.xpath("");

}
