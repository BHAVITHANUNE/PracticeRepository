package Properties;

import org.openqa.selenium.By;

public class AccessProduct_Via_Search_Properties {

	public static By SearchItem(String item) {
		return By.xpath("//*[text()='"+item+"']");
	}

	public static By Category(String Category) {
		return By.xpath("//*[text()='"+Category+"']");
	}

	public static final By Searchfield = By.xpath("//*[@placeholder='Search for anything']");
	
	public static final By Category = By.xpath("//*[@name='_sacat']");
	
	public static final By Results = By.xpath("(//*[contains(text(),' results for ')])[1]");

	


}
