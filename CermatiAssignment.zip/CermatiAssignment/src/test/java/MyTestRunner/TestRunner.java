package MyTestRunner;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;



@CucumberOptions(
		features = "src/test/java/Features",  // Path to your feature files
		glue = {"stepDefinitions"}, // Package name where step definitions are located
		tags = {"@AccessProduct_Via_Search"},
		dryRun = true,
		format = {
				"json:target/cucumber-reports/CucumberTestReport.json",
				"rerun:target/cucumrfber-reports/rerun.txt"
		},plugin = {
				"pretty",  // Console output
				"html:target/cucumber-reports.html",  // HTML report
				"json:target/cucumber-reports/Cucumber.json",  // JSON report
				"junit:target/cucumber-reports/Cucumber.xml"  // JUnit report
		},
		monochrome = true  // Makes console output more readable
		)

public class TestRunner {
	private TestNGCucumberRunner testNGCucumberRunner;
	 
    @BeforeClass(alwaysRun = true)
    public void setUpClass() throws Exception {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }
 
    @Parameters({"environment"})
    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
    public void feature(CucumberFeatureWrapper cucumberFeature) {
        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
    }
 
    @DataProvider(parallel = true)
    public Object[][] features() {
        return testNGCucumberRunner.provideFeatures();
    }
 
    @AfterClass(alwaysRun = true)
    public void tearDownClass() throws Exception {
        testNGCucumberRunner.finish();
    }

}
