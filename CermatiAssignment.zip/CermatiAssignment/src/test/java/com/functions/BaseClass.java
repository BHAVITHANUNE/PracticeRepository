package com.functions;

import java.io.File;

import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.WebDriver;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class BaseClass {
	
	StopWatch timer = new StopWatch();
	
	public static WebDriver rdriver;
	
	public static PdfPTable statusTable;
	
	public static PdfPCell cell;
	
	public static Document document;
	
	public static PdfWriter writer;
	
	public static String ClassName;

	public static String TestCaseName;

	public static File FILE;

	public static File imFILE;

}
