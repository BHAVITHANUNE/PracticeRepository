package com.functions;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GenericLib extends BaseClass {
	
	public static boolean overalRunResultFlag = false;
	
	public void fnStartWatch() throws IOException 
	{
		timer.reset();
		timer.start();
	}

	public void launchApplication(String url) throws Exception 
	{
		// Launch Browser


		String browserName=Constants.BROWSERNAME;

		try 
		{
			//Timer
			fnStartWatch();
			

			if (browserName.equalsIgnoreCase("Chrome")) 
			{

				/*System.setProperty("webdriver.chrome.driver", "./src/test/resources/driver/chromedriver.exe");
				rdriver = new ChromeDriver();*/
				
				WebDriverManager.chromedriver().setup();

		        // Create a new instance of the Chrome driver
		        WebDriver driver = new ChromeDriver();

		        // Navigate to a website
		        driver.get(url);

		        // Print the title of the page
		        System.out.println("Page title is: " + driver.getTitle());
				
		        Thread.sleep(3000);

			} 
			
			deleteAllCookie();
			rdriver.get(url);
			rdriver.manage().window().maximize();
			MutableCapabilities capabilities = new MutableCapabilities();
			HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
			browserstackOptions.put("resolution", "1024x768");
			// Set the selenium version to 4.0.0.
			browserstackOptions.put("seleniumVersion", "4.0.0");
			capabilities.setCapability("bstack:options", browserstackOptions);
			Thread.sleep(3000);
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			//Log
			
			e.printStackTrace();
		}
	}
	
	public void deleteAllCookie()
	{
		rdriver.manage().deleteAllCookies();
	}
	
	public void clickbutton(By by, String elementname) throws Exception 
	{
		// Click Button
		try 
		{
			fnStartWatch();
			WebDriverWait wait = new WebDriverWait(rdriver, 45);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			WebElement e1 = rdriver.findElement(by);
			if (e1.isDisplayed()) 
			{
				Actions actions = new Actions(rdriver);
				actions.moveToElement(e1).click().build().perform();
				LogResult_and_CaptureImage("PASS", "Click Button", "Clicked on " + elementname + " Button Successfully.", "YES");
			}
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			LogResult_and_CaptureImage("FAIL", "Click Button", "Failed To Click On " + elementname + " Button.", "YES");
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	public void LogResult_and_CaptureImage(String Status, String StepName, String StepDescription, String screenCapture, String ...pageRenderTime) 
			throws DocumentException, MalformedURLException, Exception
	{
		java.util.Date date1 = new java.util.Date();


		//******************************************************************************************************************************
		//Basic Table format
		//******************************************************************************************************************************
		try
		{


			Font blackTimesNormal = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
			Font blackTimesBold = new Font(FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);

			this.statusTable = new PdfPTable(new float[]{.5f, .5f, .2f, .6f});
			Chunk stepDetails = new Chunk("Step Details", blackTimesBold);
			Paragraph p = new Paragraph(stepDetails);
			p.setAlignment(Element.ALIGN_LEFT);
			cell = new PdfPCell(p);
			cell.setColspan(4);
			cell.setBackgroundColor(new BaseColor(208, 211, 212));
			this.statusTable.addCell(cell);

			Chunk stepNameHeading = new Chunk("Step Name", blackTimesBold);
			cell = new PdfPCell(new Paragraph(stepNameHeading));
			cell.setBackgroundColor(new BaseColor(208, 211, 212));
			this.statusTable.addCell(cell);

			Chunk stepDescriptionHeading = new Chunk("Step Description", blackTimesBold);
			cell = new PdfPCell(new Paragraph(stepDescriptionHeading));
			cell.setBackgroundColor(new BaseColor(208, 211, 212));
			this.statusTable.addCell(cell);

			Chunk statusHeading = new Chunk("Status", blackTimesBold);
			cell = new PdfPCell(new Paragraph(statusHeading));
			cell.setBackgroundColor(new BaseColor(208, 211, 212));
			this.statusTable.addCell(cell);

			Chunk timeHeading = new Chunk("Time", blackTimesBold);
			cell = new PdfPCell(new Paragraph(timeHeading));
			cell.setBackgroundColor(new BaseColor(208, 211, 212));
			this.statusTable.addCell(cell);

			//******************************************************************************************************************************
			//Appending Data To Table
			//******************************************************************************************************************************

			//When Passed
			if (Status.equalsIgnoreCase("PASS"))
			{
				//Step name
				Chunk stepName = new Chunk(StepName, blackTimesNormal);
				cell = new PdfPCell(new Paragraph(stepName));
				this.statusTable.addCell(cell);
				//Step description
				Chunk stepDescription = new Chunk(StepDescription, blackTimesNormal);
				cell = new PdfPCell(new Paragraph(stepDescription));
				this.statusTable.addCell(cell);
				//Status
				Font green = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, new BaseColor(39, 174, 96));
				Chunk greenStatus = new Chunk(Status, green);
				cell = new PdfPCell(new Paragraph(greenStatus));
				this.statusTable.addCell(cell);
				//Time
				Chunk time = new Chunk(date1.toGMTString(), blackTimesNormal);
				cell = new PdfPCell(new Paragraph(time));
				this.statusTable.addCell(cell);

			}

			//When Failed
			else if (Status.equalsIgnoreCase("Fail"))
			{
				//Step name
				Chunk stepName = new Chunk(StepName, blackTimesNormal);
				cell = new PdfPCell(new Paragraph(stepName));
				this.statusTable.addCell(cell);
				//Step description
				Chunk stepDescription = new Chunk(StepDescription, blackTimesNormal);
				cell = new PdfPCell(new Paragraph(stepDescription));
				this.statusTable.addCell(cell);
				//Status
				Font red = new Font(FontFamily.HELVETICA, 10, Font.NORMAL, new BaseColor(231, 76, 60));
				Chunk redStatus = new Chunk(Status, red);
				cell = new PdfPCell(new Paragraph(redStatus));
				this.statusTable.addCell(cell);
				//Time
				Chunk time = new Chunk(date1.toGMTString(), blackTimesNormal);
				cell = new PdfPCell(new Paragraph(time));
				this.statusTable.addCell(cell);

				//Change the result flag to "True"
				overalRunResultFlag = true;
			}

			//Update Report
			updateReport();
			if (pageRenderTime.length==1)
			{
				document.add(new Paragraph("Page Load Time : " +pageRenderTime[0]+ "secs", new Font(Font.FontFamily.HELVETICA, Font.DEFAULTSIZE, Font.BOLD)));
			}




			//Add a dummy line
			document.add(new Paragraph("\n"));

			//Screen capture if needed
			//Test Step Details: Along With Image
			//Create a Dynamic table with respect to number of test logs 
			if (screenCapture.equalsIgnoreCase("YES"))
			{
				//Add a dummy line
				document.add(new Paragraph("\n"));
				document.add(new Paragraph(new Paragraph("Screenshot : ", new Font(Font.FontFamily.HELVETICA, Font.DEFAULTSIZE, Font.BOLD))));
				//Image

				Image img = Image.getInstance(takeScreenshot());
				//If image size exceeds a threshold value decrease it to below size
				if (img.getWidth()>600.00)
				{
					img.scaleToFit(400, img.getHeight());
					img.setAlignment(Image.ALIGN_CENTER);
				}
				if (writer.getVerticalPosition(true) - document.bottom() < 160)
				{
					document.newPage();
				}
				document.add(img);

				//Add a dummy line
				document.add(new Paragraph("\n"));
			}
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateReport()
	{
		if (this.statusTable != null)

		{
			this.statusTable.setSpacingBefore(15f);
			try 
			{

				//float m_temp = writer.getVerticalPosition(true);
				//float b_temp = document.bottom();


				//If in case the page space is less add a new page
				//Add a dummy line
				document.add(new Paragraph("\n"));

				if (writer.getVerticalPosition(true)- document.bottom() < 160)
				{
					document.newPage();
				}



				//Add a line separator
				document.add(new LineSeparator(0.5f, 100, null, 0, -5));

				//Add a dummy line
				document.add(new Paragraph("\n"));

				//Add the table
				this.document.add(this.statusTable);
			}
			catch (DocumentException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.statusTable.setSpacingAfter(15f);
		}
	}
	
	private static String currentDir = System.getProperty("user.dir");
	
	protected static String takeScreenshot()
	{
		//****************************************************************************
		//Folder path creation
		//****************************************************************************
		//If Images folder is not present create an image folder in current directory
		imFILE = new File(currentDir +"\\images");
		if (!imFILE.exists())
		{
			imFILE.mkdir();
		}

		//If Screenshots folder is not present, then create a screenshot folder in current directory
		imFILE = new File(currentDir + "\\images\\Screenshots");
		if (!imFILE.exists())
		{
			imFILE.mkdir();
		}

		//****************************************************************************

		//Image Time Stamp
		java.util.Date imgTimeStamp = new java.util.Date();
		String[] imgdate1 = imgTimeStamp.toString().split(" ");
		String[] imgdate2 = imgdate1[3].split(":");
		String imgdateval = imgdate2[0] + imgdate2[1] + imgdate2[2]; 

		//ImagePath
		String imgPath = currentDir +"\\images\\ScreenShots\\page_"+imgdate1[1] + imgdate1[2] + imgdateval+".jpeg";

		//****************************************************************************

		//GetScreenShot Method Directory and Image File
		File getSreenShotMethodImageFile = new File (imgPath);

		//Take Screenshot of viewable area
		File scrFile = ((TakesScreenshot)rdriver).getScreenshotAs(OutputType.FILE);
		//Write Screenshot to a file
		try 
		{
			FileUtils.copyFile(scrFile, getSreenShotMethodImageFile);
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return imgPath;
	}
	
	public void VerifyPageDisplayedUsingPagetitle(String title) throws Exception 
	{
		try
		{
			
			boolean pageTitle = rdriver.getTitle().contains(title);
			if (pageTitle) 
			{
				LogResult_and_CaptureImage("PASS", "Verify Page Is Displayed Using Page Title", title + " Page Is Displayed", "YES", fnStopWatch());
			} 
			else
			{
				LogResult_and_CaptureImage("FAIL", "Verify Page Is Displayed Using Page Title", title + " Page Is Not Displayed ", "YES");
			}
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			LogResult_and_CaptureImage("FAIL", "Error", title + "page is not Displayed", "YES");
			e.printStackTrace();
		}
	}
	
	public String fnStopWatch() throws IOException 
	{
		timer.stop();
		return Integer.toString((int) (timer.getTime()/1000));
	}
	
	public void scrollToView(By by) throws Exception {

		try {
			WebElement e1 = rdriver.findElement(by);

			((JavascriptExecutor) rdriver).executeScript("arguments[0].scrollIntoView(true);", e1);
			Thread.sleep(3000);
		} catch (Exception e) {

			LogResult_and_CaptureImage("FAIL", "Scroll", "Failed to scroll", "YES");
			e.printStackTrace();
		}

	}
	
	public boolean VerifyObjectDisplayed(By by,String Element) throws Exception 
	{
		
		try
		{
			WebDriverWait wait = new WebDriverWait(rdriver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			WebElement e1 = rdriver.findElement(by);

			if(e1.isDisplayed())
			{

				LogResult_and_CaptureImage("PASS", "Verify"+ "Object" +  "Is Displayed",Element + "Is Displayed", "Yes");
			}
			return e1.isDisplayed();
		}
		catch (Exception e)
		{
			System.out.println("Proceeding to Else block as"+ Element+ "is not found" );
			return false;
		}
	}
	
	public void inputText(By by, String elementname, String data) throws Exception 
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(rdriver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			WebElement e1 = rdriver.findElement(by);
			if (e1.isDisplayed()) 
			{
				Actions actions = new Actions(rdriver);
				actions.moveToElement(e1).click().build().perform();
				e1.clear();
				e1.sendKeys(data);
				LogResult_and_CaptureImage("PASS", "Input Text", "'"+data+"'"+" Entered In " + elementname + " Text Field Successfully.", "NO");
			}
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			LogResult_and_CaptureImage("FAIL", "Input", "Failed To Locate " +elementname+ " Text field.", "YES");
			e.printStackTrace();
		}
	}
}
