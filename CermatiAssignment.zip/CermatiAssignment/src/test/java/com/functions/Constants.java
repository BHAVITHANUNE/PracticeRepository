package com.functions;

public class Constants {

	public static final String BROWSERNAME = "Chrome";
	
	public static final String URL= "ebay.com";
}
