package stepDefinitions;

import com.functions.GenericLib;

import Properties.AccessProduct_Via_Search_Properties;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccessProduct_Via_Search {
	
	GenericLib gl = new GenericLib();
	
	@When("^Search the any time\"([^\"]*)\"$")
	public void search_the_any_time(String item) throws Throwable {
	    
		Thread.sleep(2000);
		
		gl.inputText(AccessProduct_Via_Search_Properties.Searchfield, "Passing item name", item);
		
	}

	@When("^Slect the Category for the related item\"([^\"]*)\" and click on search button$")
	public void slect_the_Category_for_the_related_item_and_click_on_search_button(String Category) throws Throwable {
	    gl.clickbutton(AccessProduct_Via_Search_Properties.Category, "Category dropdown");
	    
	    gl.clickbutton(AccessProduct_Via_Search_Properties.Category(Category), "Category selection");
	}

	@Then("^Related items page is loaded$")
	public void related_items_page_is_loaded() throws Throwable {
	    
		gl.VerifyObjectDisplayed(AccessProduct_Via_Search_Properties.Results, "Results");
		
	}


}
