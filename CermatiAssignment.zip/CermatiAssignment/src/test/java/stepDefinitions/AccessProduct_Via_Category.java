package stepDefinitions;

import com.functions.GenericLib;

import Properties.AccessProduct_vis_Category_Properties;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccessProduct_Via_Category {

	GenericLib gl = new GenericLib();
	
	@Given("^Launch the eBay URL\"([^\"]*)\"$")
	public void launch_the_eBay_URL(String url) throws Throwable {
	     
		gl.launchApplication(url);
		
		Thread.sleep(3000);
	}

	@When("^Click on Shop By Category is next to the eBay logo$")
	public void click_on_Shop_By_Category_is_next_to_the_eBay_logo() throws Throwable {
	    gl.VerifyObjectDisplayed(AccessProduct_vis_Category_Properties.ShopCategory, "Shop By Category");
	    
		gl.clickbutton(AccessProduct_vis_Category_Properties.ShopCategory, "Shop By Category");
		Thread.sleep(2000);
	}

	@Then("^Verify Under Categories Electronics are present$")
	public void verify_Under_Categories_Electronics_are_present() throws Throwable {
	    
		gl.VerifyObjectDisplayed(AccessProduct_vis_Category_Properties.CellPhonesAccessories, "Cell Phones & Accessories");
	}

	@When("^Select the Cell phones & accessories under Electronics$")
	public void select_the_Cell_phones_accessories_under_Electronics() throws Throwable {
		
		gl.clickbutton(AccessProduct_vis_Category_Properties.CellPhonesAccessories, "Cell Phones & Accessories");
	   
	}

	@Then("^User is in Cell phones & accessories page and verify Cell Phones & Smartphones in left side of the page under Shop by Category$")
	public void user_is_in_Cell_phones_accessories_page_and_verify_Cell_Phones_Smartphones_in_left_side_of_the_page_under_Shop_by_Category() throws Throwable {
		Thread.sleep(2000);
		gl.VerifyPageDisplayedUsingPagetitle("Cell Phones, Smartphones, Smart Watches & Accessories for Sale - eBay");
		gl.VerifyObjectDisplayed(AccessProduct_vis_Category_Properties.CellPhonesCategoryPage, "Cell Phones Category Page");
	    
	}

	@When("^Click on Cell Phones & Smartphones$")
	public void click_on_Cell_Phones_Smartphones() throws Throwable {
	    
		gl.clickbutton(AccessProduct_vis_Category_Properties.CellPhonesSmartPhones, "Cell Phones & SmartPhones");
	}

	@Then("^Navigates to Cell Phones & Smartphones page and verify the All Filters in the page$")
	public void navigates_to_Cell_Phones_Smartphones_page_and_verify_the_All_Filters_in_the_page() throws Throwable {
		Thread.sleep(2000);
		gl.VerifyPageDisplayedUsingPagetitle("Cell Phones & Smartphones for Sale - Buy New & Used Phones - eBay");
		gl.scrollToView(AccessProduct_vis_Category_Properties.Filters);
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(AccessProduct_vis_Category_Properties.Filters, "Filters");
	}

	@When("^Click on All Filters Select \"([^\"]*)\", \"([^\"]*)\", and \"([^\"]*)\"$")
	public void click_on_All_Filters_Select_and(String Condition, String PriceRange, String ItemLocation) throws Throwable {
	    
		gl.clickbutton(AccessProduct_vis_Category_Properties.Filters, "Filters");
		gl.scrollToView(AccessProduct_vis_Category_Properties.Condition);
		gl.clickbutton(AccessProduct_vis_Category_Properties.Condition, "Condition");
		Thread.sleep(2000);
		
		gl.clickbutton(AccessProduct_vis_Category_Properties.Condition(Condition), "Condition is "+Condition);
		
		String MinPrice = null;
        String MaxPrice = null;
		String[] Price = PriceRange.split(",");
		if (Price.length > 0) MinPrice = Price[0];
        if (Price.length > 1) MaxPrice = Price[1];
        
        gl.inputText(AccessProduct_vis_Category_Properties.MinPrice, "Minimum Price", MinPrice);
        
        Thread.sleep(2000);
        
        gl.inputText(AccessProduct_vis_Category_Properties.MaxPrice, "Max Price", MaxPrice);
        
        Thread.sleep(2000);
        
        gl.clickbutton(AccessProduct_vis_Category_Properties.ItemLocation, "Item Clocation");
        
        Thread.sleep(2000);
        
        gl.clickbutton(AccessProduct_vis_Category_Properties.Itemlocation(ItemLocation), "Item Location");
        
        Thread.sleep(2000);
        
        gl.clickbutton(AccessProduct_vis_Category_Properties.ApplyButton, "Apply Button");
	}

	@Then("^Verify Codition, Price, and Item Location filter tags are applied$")
	public void verify_Codition_Price_and_Item_Location_filter_tags_are_applied() throws Throwable {
	    
		gl.VerifyObjectDisplayed(AccessProduct_vis_Category_Properties.FilterAppled, "Filter appled");
		
		gl.VerifyObjectDisplayed(AccessProduct_vis_Category_Properties.itemsFound, "No of Items Found");
	}
}
